export type User = {
    id? : number,
	nome : string ,
    email : string,
    senha : string,
    morada : string,
    codpost : string,
    pais : string
}