export type User = {
    id? : number,
	nome : string ,
    email : string,
    senha : string,
    morada : string,
    codigoPostal : string,
    pais : string,
    active : boolean,
    admin : boolean,
    wishList : number[]
}